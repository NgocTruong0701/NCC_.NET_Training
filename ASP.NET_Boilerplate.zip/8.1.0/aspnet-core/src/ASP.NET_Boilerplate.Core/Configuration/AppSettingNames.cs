﻿namespace ASP.NET_Boilerplate.Configuration
{
    public static class AppSettingNames
    {
        public const string UiTheme = "App.UiTheme";
    }
}
